

<?php $__env->startSection('title','Recent Violation'); ?>

<?php $__env->startSection('header'); ?>
    <h1>STUDENT VIOLATION TRACKER</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('violation-content'); ?>
    <div class="violation-recent">
        <h1 class="d-block">RECENT VIOLATIONS</h1>
        <div class="violation-content">
            <div class="recent-table-wrapper">
                <table class="table" id="admin-table">
                    <thead>
                        <tr class="table-header">
                            <th>ID Number</th>
                            <th>Violation</th>
                            <th>Violation Date</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('user_violation')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        $('#recent-violation-menu').css('background-color', '#62B485');
        $("#admin-table").DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('user_violation_recent')); ?>",
            columns: [
                { data: "username", name: "username" },
                { data: "violation", name: "violation" },
                { data: 'created_at', name: 'created_at'}
            ],
            
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\violations\recent.blade.php ENDPATH**/ ?>