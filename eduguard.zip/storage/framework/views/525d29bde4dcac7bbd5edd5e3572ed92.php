

<?php $__env->startSection('title','Forgot Password'); ?>

<?php $__env->startSection('header'); ?>
    <img class="img-logo" src="../storage/logo.png" alt="Logo">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('password.email')); ?>" class="reset-form" method="post">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label class="form-label" for="email">Email</label>
                    <input type="text" class="form-input" name="email" id="email">
                </div>
                <button class="button w-5 login mb-2 text-center">Reset</button>
                <a href="<?php echo e(route('login')); ?>"><h3>go back to login?</h3></a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/forgot.blade.php ENDPATH**/ ?>