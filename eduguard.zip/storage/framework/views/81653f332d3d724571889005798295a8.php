

<?php $__env->startSection('title','Exam'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="user">
        <div class="user-header">
            <a href="<?php echo e(route('exam')); ?>" class="button w-2 text-center button-new">New</a>
        </div>
        <div class="user-body">
            <div class="user-table-wrapper">
                <table class="table cell-border compact stripe" id="admin-table">
                    <?php echo csrf_field(); ?>
                    <thead>
                        <tr class="table-header">
                            <th>#</th>
                            <th>Exam Name</th>
                            <th>Strand</th>
                            <th>Created Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
        $('#exam-menu-item').css('background-color', '#62B485');
        $("#admin-table").DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('admin_exam')); ?>",
            columns: [
                { data: 'DT_RowIndex', "searchable":false },
                { data: "name", name: "name" },
                { data: "strand", name: "strand" },
                { data: "created_at", name: "created_at" },
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],            
        });

        $('#admin-table').on('click', '#updateExam', function () {
            let id = $(this).data('id');
            window.location.href = "/exam/" + id
        });

        $('#admin-table').on('click', '#viewExam', function () {
            let id = $(this).data('id');
            window.location.href = "/exam/preview/" + id
        });
    });

    function deleteExam(id) {
        var url = "<?php echo e(route('delete_exam', 'id')); ?>";
        var token = document.getElementsByName("_token")[0].value;
        url = url.replace('id', id);
        $.ajax({
            url: url,
            method: 'DELETE',
            data: {
                    "id": id,
                    "_method": 'DELETE',
                    "_token": token,
            },
            dataType: 'JSON',
            success: function ()
            {
                swal('Success', 'Successfully deleted', 'sucess')
                window.location.reload()
            }
        });
    }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/admin/exam/index.blade.php ENDPATH**/ ?>