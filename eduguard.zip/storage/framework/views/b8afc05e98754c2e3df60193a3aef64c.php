

<?php $__env->startSection('title','Reset Password'); ?>

<?php $__env->startSection('header'); ?>
    <img class="img-logo" src="../../storage/logo.png" alt="Logo">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="/login" class="login-form" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($token); ?>">
                <div class="form-group">
                    <label class="form-label" for="username">Username:</label>
                    <input type="text" class="form-input" name="username" id="username">
                </div>
                <div class="form-group">
                    <label class="form-label" for="password">password:</label>
                    <input type="password" class="form-input" name="password" id="password">
                </div>
                <div class="form-footer">
                    <button class="button w-5 login mb-2 text-center" type="submit">
                        Login
                    </button>
                    <h3>forgot your password? click here to reset your password</h3>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\reset.blade.php ENDPATH**/ ?>