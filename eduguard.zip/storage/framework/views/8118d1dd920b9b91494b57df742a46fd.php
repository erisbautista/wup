

<?php $__env->startSection('title','History'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="user">
        <div class="violation-header">
            <h1>Record History</h1>
        </div>
        <div class="user-body">
            <div class="user-table-wrapper">
                <table class="table cell-border compact stripe" id="admin-table">
                    <?php echo csrf_field(); ?>
                    <thead>
                        <tr class="table-header">
                            <th>#</th>
                            <th>Table Name</th>
                            <th>Record Updated</th>
                            <th>Field Update</th>
                            <th>From</th>
                            <th>To</th>
                            <th>Updated By</th>
                            <th>Created Date</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
            $('#history-menu-item').css('background-color', '#62B485');
            $("#admin-table").DataTable({
                processing: true,
                serverSide: true,
                ajax: "<?php echo e(route('admin_history')); ?>",
                columns: [
                    { data: 'DT_RowIndex', "searchable":false },
                    { data: "table_name", name: "table_name" },
                    { data: "record", name: "record" },
                    { data: "field", name: "field" },
                    { data: "from", name: "from" },
                    { data: "to", name: "to" },
                    { data: "user_id", name: "user_id" },
                    { data: "created_at", name: "created_at" },
                ],
                
            });

            $('#admin-table').on('click', '#updateViolation', function () {
                let id = $(this).data('id');
                window.location.href = "/violation/" + id
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/admin/history.blade.php ENDPATH**/ ?>