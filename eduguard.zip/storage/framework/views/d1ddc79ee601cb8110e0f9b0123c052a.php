

<?php $__env->startSection('title','Calendar'); ?>

<?php $__env->startSection('header'); ?>
    <h1>SCHOOL CALENDAR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('calendar-content'); ?>
    <div class="calendar-home">
        <div class="section mb-2">
            <span class="heading text-center">Current Day</span>
            <div class="activity-wrapper">
                <?php $__currentLoopData = $data['current']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $current): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="activity">
                        <div class="activity-date"><?php echo e($current->start_date . ' to ' . $current->end_date); ?></div>
                        <div class="activity-title"><?php echo e($current->description); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="section">
            <span class="heading text-center">upcoming</span>
            <div class="activity-wrapper">
                <?php $__currentLoopData = $data['upcomming']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $upcomming): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="activity">
                        <div class="activity-date"><?php echo e($upcomming->start_date . ' to ' . $upcomming->end_date); ?></div>
                        <div class="activity-title"><?php echo e($upcomming->description); ?></div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('home')); ?>">
    Main Menu
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
        $('#activity-menu-activity').css('background-color', '#62B485');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/calendar.blade.php ENDPATH**/ ?>