

<?php $__env->startSection('title','Activity'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="user">
        <div class="user-header">
            <a href="<?php echo e(route('create_activity_view')); ?>" class="button w-2 text-center button-new">New</a>
        </div>
        <div class="user-body">
            <div class="user-table-wrapper">
                <table class="table cell-border compact stripe" id="admin-table">
                    <?php echo csrf_field(); ?>
                    <thead>
                        <tr class="table-header">
                            <th>#</th>
                            <th>Description</th>
                            <th>Start Date</th>
                            <th>End Date</th>
                            <th>Created by</th>
                            <th>Created Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
        $('#activity-menu-item').css('background-color', '#62B485');
        $("#admin-table").DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('admin_activity')); ?>",
            columns: [
                { data: 'DT_RowIndex', "searchable":false },
                { data: "description", name: "description" },
                { data: "start_date", name: "start_date" },
                { data: "end_date", name: "end_date" },
                { data: "user_id", name: "user_id" },
                { data: "created_at", name: "created_at" },
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            
        });

        $('#admin-table').on('click', '#updateActivity', function () {
            let id = $(this).data('id');
            window.location.href = "/activity/" + id
        });
    });
    function deleteActivity(id)
        {
            var url = "<?php echo e(route('delete_activity', 'id')); ?>";
            var token = document.getElementsByName("_token")[0].value;
            url = url.replace('id', id);
            $.ajax({
                url: url,
                method: 'DELETE',
                data: {
                        "id": id,
                        "_method": 'DELETE',
                        "_token": token,
                },
                dataType: 'JSON',
                success: function ()
                {
                    swal('Success', 'Successfully deleted', 'sucess')
                    window.location.reload()
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\admin\activity\index.blade.php ENDPATH**/ ?>