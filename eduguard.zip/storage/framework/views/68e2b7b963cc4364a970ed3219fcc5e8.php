

<?php $__env->startSection('title','Create Question'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="question">
        <div class="question-header">
            <h1 class="text-uppercase">Create new Question</h1>
        </div>
        <div class="question-body">
            <form action="<?php echo e(route('create_question', $id)); ?>" method="POST" class="question-form">
                <?php echo csrf_field(); ?>
                <label for="question">Question</label>
                <textarea name="question" id="question" class="textarea-input"></textarea>
                <div class="question-form-footer content-center">
                    <button class="button w-2 text-center" type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(url()->previous()); ?>">
        back
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
        $('#exam-menu-item').css('background-color', '#62B485');
        $('.question-form').submit(function(event) {
            if($('#question').val() === ''|| $('#question').val() === null){
                $('#question').addClass('warning');
                swal('Question field is required', '', 'error');
                event.preventDefault();
            } else {
                $('#question').removeClass('warning');
            }
        })
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\admin\exam\question\create.blade.php ENDPATH**/ ?>