<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/main.scss', 'resources/js/app.js']); ?>
    </head>
    <body>
        <div class="container">
            <div class="header mb-4">
                <?php echo $__env->yieldContent('header'); ?>
            </div>
            <div class="main">
                <?php echo $__env->yieldContent('ncae-menu'); ?>
                <div class="content">
                    <div class="card">
                        <?php echo $__env->yieldContent('ncae-content'); ?>
                    </div>
                </div>
                <div class="footer">
                    <?php echo $__env->yieldContent('footer'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\wup\resources\views///////layouts/ncae.blade.php ENDPATH**/ ?>