

<?php $__env->startSection('title','Update Violation'); ?>

<?php $__env->startSection('header'); ?>
    <h1>STUDENT VIOLATION TRACKER</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('violation-content'); ?>
    <div class="register-violation">
        <h1 class="d-block">REGISTER VIOLATION</h1>

        <form action="<?php echo e(route('user_violation_update', $data['userViolations']->id)); ?>" method="POST" class="violation-register-form" id="register-user-violation-form">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <div class="form-group">
                <label for="id_number" class="form-label">Student:</label>
                <input readonly disabled="disabled" type="text" value="<?php echo e($data['userViolations']->user->first_name . ' ' . $data['userViolations']->user->middle_name .' ' . $data['userViolations']->user->last_name); ?>" class="form-input">
            </div>
            <div class="form-group">
                <label for="violation" class="form-label">Violation:</label>
                <select name="violation_id" id="violation_id" class="input-select color-black">
                    <option value="">Select violation</option>
                    <?php $__currentLoopData = $data['violations']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $violation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo $violation->id; ?>" <?php echo e($data['userViolations']->violation_id === $violation->id ? 'selected="selected"' : null); ?>><?php echo e($violation->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="category" class="form-label">Category No.:</label>
                <input readonly disabled="disabled" type="text" value="<?php echo e($data['userViolations']->violation->category_no); ?>" id="category_no" class="form-input">
            </div>
            <div class="form-footer">
                <button onclick="submitForm()" type="button" class="button w-5 text-center">Save</button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('user_violation')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        var data = <?php echo json_encode($data['violations']); ?>

        $('#register-violation-menu').css('background-color', '#62B485');
        $('#user_id').select2();
        $('#violation_id').select2();

        $('#violation_id').on('select2:select', function (e) {
            var selectedId = parseInt(e.params.data.id);
            if (!selectedId) {
                $('#category_no').val('')
            }

            data.map(function (d) {
                if (d.id === selectedId) {
                    $('#category_no').val(d.category_no)
                }
            })
        });
    });

    function submitForm() {
        $('#activity-submit').attr('disabled', 'disabled');
        setTimeout(function() {
            $('#activity-submit').removeAttr('disabled');
        }, 1000);
        if($('#violation_id').val().length === 0) {
            swal('Please select violation!', '', 'info');
            return 0;
        }

        $('#register-user-violation-form').submit();
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/violations/update.blade.php ENDPATH**/ ?>