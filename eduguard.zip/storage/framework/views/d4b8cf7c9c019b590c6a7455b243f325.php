

<?php $__env->startSection('title','Users'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="user">
        <div class="user-header">
            <a href="<?php echo e(route('create_user')); ?>" class="button w-2 text-center button-new">New</a>
        </div>
        <div class="user-body">
            <div class="user-table-wrapper">
                <table class="table cell-border compact stripe" id="admin-table">
                    <?php echo csrf_field(); ?>
                    <thead>
                        <tr class="table-header">
                            <th>#</th>
                            <th>First Name</th>
                            <th>Middle Name</th>
                            <th>Last Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Username</th>
                            <th>Created Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#user-menu-item').css('background-color', '#62B485');
        $("#admin-table").DataTable({
            processing: true,
            serverSide: true,
            ajax: "<?php echo e(route('admin_user')); ?>",
            columns: [
                { data: 'DT_RowIndex', "searchable":false },
                { data: "first_name", name: "first_name" },
                { data: "middle_name", name: "middle_name" },
                { data: "last_name", name: "last_name" },
                { data: "email", name: "email" },
                { data: 'role', name: 'role' },
                { data: "username", name: "username" },
                { data: "created_at", name: "created_at" },
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            
        });

        $('#admin-table').on('click', '#updateUser', function () {
            let id = $(this).data('id');
            window.location.href = "/user/" + id
        });
        $('#admin-table').on('click', '#changePassword', function () {
            let id = $(this).data('id');
            window.location.href = "/user/password/" + id
        });

        
    });
    function deleteUser(id)
    {
        var url = "<?php echo e(route('delete_user', 'id')); ?>";
        var token = document.getElementsByName("_token")[0].value;
        url = url.replace('id', id);
        $.ajax({
            url: url,
            method: 'DELETE',
            data: {
                    "id": id,
                    "_method": 'DELETE',
                    "_token": token,
            },
            dataType: 'JSON',
            success: function ()
            {
                swal('Success', 'Successfully deleted', 'sucess')
                window.location.reload()
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/admin/user/index.blade.php ENDPATH**/ ?>