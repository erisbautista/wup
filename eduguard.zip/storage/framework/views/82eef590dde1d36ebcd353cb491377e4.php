

<?php $__env->startSection('title','Violation Record'); ?>

<?php $__env->startSection('header'); ?>
    <h1>STUDENT VIOLATION TRACKER</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('violation-content'); ?>
    <div class="violation-record">
        <h1 class="d-block">STUDENT RECORDS</h1>

        <form class="violation-record-form">
            <?php echo csrf_field(); ?>
            <div class="form-group mr-2 violation-record-form-input">
                <label for="id_number" class="form-label">Student:</label>
                <select name="user_id" id="user_id" class="input-select">
                    <option value="">Select user</option>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo $user->id; ?>"><?php echo e($user->first_name . ' ' . $user->middle_name .' ' . $user->last_name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-footer">
                <button onclick="submitForm()" type="button" class="button">Enter</button>
            </div>
        </form>
        
        <div class="violation-content">
            <div class="name">
                <span>Name: </span> <span id="student-name"></span>
            </div>
            <div class="level">
                <span>Level: </span> <span id="student-level"></span>
            </div>
            <div class="remarks">
                <span>Remarks: </span> <span id="student-remarks"></span>
            </div>
            <div class="violations">
                <span>Violations:</span>
                <div class="table-wrapper">
                    <table class="table" id="admin-table">
                        <thead class="table-header">
                            <tr>
                                <th>Violation</th>
                                <th>Violation Date</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('user_violation')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    var datatables = $("#admin-table").DataTable();
    document.addEventListener("DOMContentLoaded", function () {
        $('#record-violation-menu').css('background-color', '#62B485');
        $('#user_id').select2();

        $('#admin-table').on('click', '#updateViolation', function () {
            let id = $(this).data('id');
            window.location.href = "/user/violation/update/" + id
        });
    });
    function submitForm(){
        var id = $('#user_id').val();
        if(id.length === 0)
        {
            swal('Please select a user first', '', 'info');
            return 0;
        }
        var url = "<?php echo e(route('user_violation_record_search')); ?>";
        var token = document.getElementsByName("_token")[0].value;
        $.ajax({
            url: url,
            method: 'POST',
            data: {
                    "user_id": id,
                    "_method": 'post',
                    "_token": token,
            },
            dataType: 'JSON',
            success: function (data)
            {
                if (data.data.length > 0) {
                    let user = data.data[0]['user']
                    $('#student-name').html(user['first_name'] + ' ' + user['middle_name'] + ' ' + user['last_name'])  
                    $('#student-level').html(user['level'])
                    data.data.length >= 3 ? $('#student-remarks').html('For Suspension') : $('#student-remarks').html('N/A')
                }
                $("#admin-table").DataTable({
                    destroy: true,
                    data: data.data,
                    columns: [
                        { data: "violation", name: "violation" },
                        { data: 'created_at', name: 'created_at'},
                        { data: 'action', name: 'action', "searchable":false}
                    ],
                });
            }
        });
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/violations/record.blade.php ENDPATH**/ ?>