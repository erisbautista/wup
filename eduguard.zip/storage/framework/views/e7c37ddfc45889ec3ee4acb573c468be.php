

<?php $__env->startSection('title','Reset Password'); ?>

<?php $__env->startSection('header'); ?>
    <img class="img-logo" src="../../storage/logo.png" alt="Logo">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('password.update')); ?>" class="reset-form" method="post">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="token" value="<?php echo e($data['token']); ?>">
                <div class="form-group">
                    <label class="form-label" for="username">Email</label>
                    <input type="text" class="form-input" name="email" value="<?php echo e($data['email'] ?? old('email')); ?>" readonly>
                </div>
                <div class="form-group">
                    <label class="form-label" for="password">password</label>
                    <input type="password" class="form-input" name="password" id="password">
                </div>
                <div class="form-group">
                    <label class="form-label" for="password">Confirm password</label>
                    <input type="password" class="form-input" name="password_confirmation" id="password_confirmation">
                </div>
                <div class="form-footer">
                    <button class="button w-5 login mb-2 text-center" type="submit">
                        Login
                    </button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('#password_confirmation').focusout(function() {
            $(this).val($(this).val().trim());
            var confirm_password = $(this).val();
            var password = $('#password').val();
            if(password === '' || password === null || $(this).val() === null || $(this).val() === '') {
                return 0;
            }

            if(password === confirm_password) {
                return 0;
            }
            swal('Password Mismatch', '', 'error');
            $(this).val('');
        })
        $('#password').focusout(function() {
            $(this).val($(this).val().trim());
            var password = $(this).val();
            var confirm_password = $('#password_confirmation').val();
            if(confirm_password === '' || confirm_password === null || $(this).val() === null || $(this).val() === '') {
                return 0;
            }
            if(password === confirm_password) {
                return 0;
            }
            swal('Password Mismatch', '', 'error');
            $(this).val('');
        })  
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/reset.blade.php ENDPATH**/ ?>