

<?php $__env->startSection('title','Create Exam'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="exam">
        <div class="exam-header">
            <h1 class="text-uppercase">Create new Exam</h1>
        </div>
        <div class="exam-body">
            <form action="<?php echo e(route('create_exam')); ?>" method="POST" class="exam-form">
                <?php echo csrf_field(); ?>
                <div class="inline-group mr-2 self-center">
                    <div class="form-group self-end">
                        <label for="name">Exam Name</label>
                        <input type="text" name="name" id="name" class="form-input">
                    </div>
                    <div class="form-group">
                        <label for="strand_id">Strand</label>
                        <select name="strand_id" id="strand_id" class="input-select">
                            <option value="">Select strand</option>
                            <?php $__currentLoopData = $strands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo $strand->id; ?>"><?php echo e($strand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="exam-form-footer content-center">
                    <button class="button w-2 text-center" type="submit">Save</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
        $('#exam-menu-item').css('background-color', '#62B485');
        $('#strand_id').select2();
        $('.exam-form').submit(function(event) {
            var errors = 0;
            $(".exam-form input, .exam-form select").map(function(){
                $(this).val($(this).val().trim());
                if( !$(this).val() || $(this).val() === null) {
                    $(this).addClass('warning');
                    errors++;
                } else if ($(this).val()) {
                    $(this).removeClass('warning');
                }
            });
            if(errors > 0){
                swal('All fields is required', '', 'error');
                event.preventDefault();
            }
        })
    });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\admin\exam\create.blade.php ENDPATH**/ ?>