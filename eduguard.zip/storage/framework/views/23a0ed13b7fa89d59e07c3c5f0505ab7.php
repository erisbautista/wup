

<?php $__env->startSection('title','Main Menu'); ?>

<?php $__env->startSection('header'); ?>
    <img class="img-logo" src="storage/logo.png" alt="Logo">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="menu">
        <a href="<?php echo e(route('calendar')); ?>" class="btn-menu text-center">School calendar</a>
        <a href="<?php echo e(route('ncae')); ?>" class="btn-menu text-center">ncae pre-test</a>
        <?php if(auth()->user()->role_id === 3): ?>
        <a href="<?php echo e(route('user_violation')); ?>" class="btn-menu text-center">Student Violation tracker</a>
        <?php endif; ?>
        <a  class="button text-center" href="<?php echo e(route('logout')); ?>">Log out</a>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/home.blade.php ENDPATH**/ ?>