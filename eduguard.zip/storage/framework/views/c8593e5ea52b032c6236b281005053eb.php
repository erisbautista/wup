

<?php $__env->startSection('title','Update Violation'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="violation-create">
        <div class="violation-create-header">
            <h1 class="text-uppercase">Update Violation</h1>
        </div>
        <div class="violation-create-body">
            <form action="<?php echo e(route('update_violation', $violation->id)); ?>" method="POST" class="violation-create-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label for="name" class="form-label">Violation Name</label>
                    <input type="text" class="form-input" value="<?php echo e($violation->name); ?>" name="name" id="name">
                </div>
                <div class="form-group">
                    <label for="category_no" class="form-label">Category No</label>
                    <input type="text" class="form-input" value="<?php echo e($violation->category_no); ?>" name="category_no" id="category_no">
                </div>
                <div class="violation-create-form-footer">
                    <button class="button w-3 text-center">Edit</button>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\admin\violation\update.blade.php ENDPATH**/ ?>