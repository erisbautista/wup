

<?php $__env->startSection('title','Calendar'); ?>

<?php $__env->startSection('header'); ?>
    <h1>SCHOOL CALENDAR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('calendar-content'); ?>
    <div class="calendar-wrapper">
        <?php if(auth()->user()->role_id === 3): ?>
        <a href="<?php echo e(route('calendar_activity')); ?>" class="button w-2 text-center button-new mb-4">New</a>
        <?php endif; ?>
        <div id="calendar"></div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('calendar')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        $('#activity-menu-calender').css('background-color', '#62B485');
        var activities = <?php echo json_encode($activities); ?>;
        const calendarEl = document.getElementById("calendar");
        const calendar = new FullCalendar.Calendar(calendarEl, {
            headerToolbar: {
                left: "prev,next today",
                center: "title",
                right: "dayGridMonth,timeGridWeek,timeGridDay",
            },
            selectable: true,
            eventClick: function (event) {
                moment(event.event.end).format('MMMM DD, YYYY HH:mm') === 'Invalid date' ? swal(moment(event.event.start).format('MMMM DD, YYYY HH:mm'), event.event.title, 'info') : swal(moment(event.event.start).format('MMMM DD, YYYY HH:mm') + ' to ' + moment(event.event.end).format('MMMM DD, YYYY HH:mm'), event.event.title, 'info');
            },
        });
        calendar.addEventSource(activities);
        calendar.render();
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\calendar\view.blade.php ENDPATH**/ ?>