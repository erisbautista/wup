<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Pre-test</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.css"/>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.css" />
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-modal/0.9.1/jquery.modal.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-bundle.min.js"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/main.scss', 'resources/js/app.js']); ?>
    </head>
    <body>
        <div class="container">
            <div class="header mb-4">
                <h1>NCAE PRE-TEST</h1>
            </div>
            <div class="ncae-test">
                <div class="question card">
                    <div class="swiper">
                        <!-- Additional required wrapper -->
                        <div class="swiper-wrapper">
                            <?php echo csrf_field(); ?>
                            <?php ($count = 1); ?>
                        <!-- Slides -->
                            <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $exam->questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="swiper-slide">
                                        <div class="slider-content">
                                            <span class="question-title"><?php echo e($exam->name); ?></span>
                                            <h1><?php echo e($count . '. '. $question->question); ?></h1>
                                            <?php $__currentLoopData = $question->choices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $choice): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <label class="radio">
                                                <span class="radio-input">
                                                <input data-exam="<?php echo e($exam->id); ?>" data-question="<?php echo e($question->id); ?>" onclick="setAnswer(<?php echo e($exam->id); ?>, <?php echo e($question->id); ?>, <?php echo e($choice->id); ?>)" type="radio" value="<?php echo e($choice->id); ?>" name="<?php echo e($question->id); ?>">
                                                <span class="radio-control"></span>
                                                </span>
                                                <span class="radio-label"><?php echo e($choice->label); ?></span>
                                            </label>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                    <?php ($count++); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="swiper-pagination"></div>
                        <!-- If we need scrollbar -->
                        <div class="swiper-scrollbar"></div>
                    </div>
                    
                    <div class="navigation">
                        <button class="button-previous w-3 text-center m-5">Previous</button>
                        <button onclick="checkStatus()" class="button-go w-3 text-center m-5">Go to</button>
                        <button class="button-next w-3 text-center m-5">Next</button>
                        <button onclick="submitForm()" class="button-submit w-3 text-center m-5">Check Result</button>
                    </div>
                </div>
            </div>
        </div>
        <script>
            var swiper;
            var question_length;
            var exam_data = <?php echo json_encode($exams); ?>;
            var data = [];
            var token = document.getElementsByName("_token")[0].value;
            $(document).ready(function () {
                // $('#exam-menu-item').css('background-color', '#62B485');
                swiper = new Swiper('.swiper', {
                    // Optional parameters
                    hashNavigation: true,
    
                    // If we need pagination
                    pagination: {
                        el: '.swiper-pagination',
                        clickable: true,
                        dynamicBullets: true,
                        type: "fraction"
                    },
    
                    // Navigation arrows
                    navigation: {
                        nextEl: '.button-next',
                        prevEl: '.button-previous',
                    },
    
                    // And if we need scrollbar
                    scrollbar: {
                        el: '.swiper-scrollbar',
                    },
                });

                question_length = swiper.slides.length;
                prepareData();
            });

            function checkStatus() {
                var unansweredEl = document.createElement('div');
                $(unansweredEl).addClass('question-list-unfinished');
                $.each(data, function(key, value) {
                    $(unansweredEl).append(`<span onclick="swiperNavigate(`+ key +`)">` + (key + 1) + `</span>`);
                })
                swal("Select from the following questions:", {
                    content: unansweredEl,
                    buttons: false
                })
            }

            function swiperNavigate(key) {
                swiper.slideTo(key);
                swal.close();
            }

            function setAnswer(exam_id, question_id, choice_id) {
                $.each(data, function(key, value) {
                    if(value.exam_id === exam_id && value.question_id === question_id) {
                        data[key].answer = choice_id;
                    }
                });
            }

            function prepareData() {
                $.each(exam_data, function(key, question) {
                    $.each(question.questions, function(key, value) {
                        data.push({
                            exam_id: value.exam_id,
                            question_id: value.id,
                            answer: null
                        })
                    })
                })
            }

            function submitForm() {
                var count = 0;
                $.each(data, function(key, value) {
                    if(value.answer ===null) {
                        count++;
                    }
                })

                if( count > 0 ) {
                    swal(
                        {
                            text: 'There are '+ count + ' more questions to answer! Are you sure you want to submit the form?',
                            icon: "warning",
                            buttons: true,
                            dangerMode: true,
                        }
                    ).then((confirm) => {
                        if (confirm) {
                            $.ajax({
                                url: "<?php echo e(route('ncae_test_submit')); ?>",
                                method: 'POST',
                                data: {
                                        "data": data,
                                        "_token": token,
                                },
                                dataType: 'JSON',
                                success: function (data)
                                {
                                    if(data['status'] === true) {
                                        swal('successfully submitted to exam!', {
                                            icon: 'success',
                                            buttons: false
                                        });
                                        window.location.href = '/ncae/result'
                                    }
                                }
                            });
                        }
                    });
                }
            }
        </script>
        <?php echo $__env->make('../../components/ncaeModal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </body>
</html><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\ncae\test.blade.php ENDPATH**/ ?>