<!DOCTYPE html>
<html class="h-full" lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    </head>
    <body class="h-full bg-primary-100">
        <div class="h-full flex flex-col justify-center items-center gap-4 pb-16">
            <div class="header mb-4">
                <?php echo $__env->yieldContent('header'); ?>
            </div>
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('scripts'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\wup\resources\views////layouts/dummy.blade.php ENDPATH**/ ?>