

<?php $__env->startSection('title','Violation Analysis'); ?>

<?php $__env->startSection('header'); ?>
    <h1>STUDENT VIOLATION TRACKER</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('violation-content'); ?>
    <div class="violation-analysis">
        <h1 class="d-block">VIOLATION ANALYSIS</h1>
        <div class="violation-chart">
            <?php echo $chart->render(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('user_violation')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        $('#analysis-violation-menu').css('background-color', '#62B485');
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\violations\analysis.blade.php ENDPATH**/ ?>