

<?php $__env->startSection('title','Feedback'); ?>

<?php $__env->startSection('header'); ?>
    <h1>SCHOOL CALENDAR</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('calendar-content'); ?>
    <div class="calendar-feedback">
        <form class="calendar-feedback-form">
            <div class="calendar-feedback-header text-center">
                <span>Let us know what to improve! Put your feedback and recommendations below!</span>
            </div>
            <div class="calendar-feedback-body">
                <textarea name="feedback-input" class="feedback-input"></textarea>
            </div>
            <div class="calendar-feedback-footer">
                <button class="feedback-submit">
                    submit
                </button>
            </div>
        </form>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('calendar')); ?>">
    back
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/calendar/feedback.blade.php ENDPATH**/ ?>