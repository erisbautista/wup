<div id="ncae-modal" class="modal">
    <div class="modal-body">
        Test
    </div>
</div><?php /**PATH C:\xampp\htdocs\wup\resources\views///////components/ncaeModal.blade.php ENDPATH**/ ?>