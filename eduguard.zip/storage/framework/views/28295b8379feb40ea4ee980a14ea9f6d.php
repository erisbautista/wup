

<?php $__env->startSection('title','Create Activity'); ?>

<?php $__env->startSection('style'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('admin-content'); ?>
    <?php echo $__env->make('components.activity', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $('document').ready(function() {
            var startPicker = flatpickr('input[type="date"]',{
                altInput: true,
                enableTime: true,
                altFormat: "F j, Y H:i K",
                dateFormat: "Y-m-d H:i",
            });
        },);

        function checkDateValid(startDate, endDate) {
            if (startDate > endDate) {
                swal('Invalid Input', 'End date cannot be less than the start date.', 'error');
                return false;
            }
            return true;
        }

        function checkIfFieldEmpty(data, field) {
            if(data === '' || data === null) {
                swal('Invalid Input', field + ' cannot be empty.', 'error');
                return false;
            }
            return true;
        }

        function submitForm() {
            $('#activity-submit').attr('disabled', 'disabled');
            setTimeout(function() {
                $('#activity-submit').removeAttr('disabled');
            }, 1000);
            var endDate = $('#end_date').val();
            var startDate = $('#start_date').val();
            var description = $('#description').val();
            var startDateIsNotEmpty = checkIfFieldEmpty(startDate, 'Start Date');
            var endDateIsNotEmpty = checkIfFieldEmpty(endDate, 'End Date');
            var descriptionIsNotEmpty = checkIfFieldEmpty(description, 'Description');
            var validDate = checkDateValid(startDate, endDate);
            if(startDateIsNotEmpty === false || endDateIsNotEmpty === false || descriptionIsNotEmpty === false || validDate === false) {
                console.log('invalid form');
                return 0;
            }
            $('#history-form').submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('logout')); ?>">
        Log out
    </a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/admin/activity/create.blade.php ENDPATH**/ ?>