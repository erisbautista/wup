

<?php $__env->startSection('title','Exam Details'); ?>

<?php $__env->startSection('admin-content'); ?>
    <div class="exam">
        <div class="exam-header">
            <h1 class="text-uppercase">Update Exam</h1>
        </div>
        <div class="exam-body">
            <form action="<?php echo e(route('update_exam', $data['exam']->id)); ?>" method="POST" class="exam-form">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="inline-group mr-2 self-center">
                    <div class="form-group self-end">
                        <label for="name">Exam Name</label>
                        <input type="text" name="name" id="name" value="<?php echo e($data['exam']->name); ?>" class="form-input">
                    </div>
                    <div class="form-group">
                        <label for="strand_id">Strand</label>
                        <select name="strand_id" id="strand_id" value="<?php echo e($data['exam']->strand_id); ?>" class="input-select">
                            <option value="">Select strand</option>
                            <?php $__currentLoopData = $data['strands']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo $strand->id; ?>"><?php echo e($strand->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="exam-form-footer content-center">
                    <button class="button w-2 text-center" type="submit">Save</button>
                </div>
            </form>
            <div class="exam-questions">
                <div class="exam-questions-header">
                    <a href="<?php echo e(route('question', $data['exam']->id)); ?>" class="button w-4 text-center button-new">New Question</a>
                </div>
                <div class="exam-questions-body">
                    <div class="exam-table-wrapper">
                        <table class="table cell-border compact stripe" id="admin-table">
                            <?php echo csrf_field(); ?>
                            <thead>
                                <tr class="table-header">
                                    <th>#</th>
                                    <th>question</th>
                                    <th>Created Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
    <a class="button w-5 text-center" href="<?php echo e(route('admin_exam')); ?>">
        back
    </a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function () {
        $('#exam-menu-item').css('background-color', '#62B485');
        $('#strand_id').select2();
        $('#strand_id').val(<?php echo json_encode($data['exam']['strand_id']); ?>); // Select the option with a value of '1'
        $('#strand_id').trigger('change');
        $('.exam-form').submit(function(event) {
            var errors = 0;
            $(".exam-form input, .exam-form select").map(function(){
                $(this).val($(this).val().trim());
                if( !$(this).val() || $(this).val() === null) {
                    $(this).addClass('warning');
                    errors++;
                } else if ($(this).val()) {
                    $(this).removeClass('warning');
                }
            });
            if(errors > 0){
                swal('All fields is required', '', 'error');
                event.preventDefault();
            }
        })
        var url = "<?php echo e(route('get_exam', ':id')); ?>";
        url = url.replace(':id', <?php echo json_encode($data['exam']['id']); ?>);
        
        $("#admin-table").DataTable({
            processing: true,
            serverSide: true,
            ajax: url,
            columns: [
                { data: 'DT_RowIndex', "searchable":false },
                { data: "question", name: "question" },
                { data: "created_at", name: "created_at" },
                {data: 'action', name: 'action', orderable: false, searchable: false},
            ],
            
        });

        $('#admin-table').on('click', '#updateQuestion', function () {
            let id = $(this).data('id');
            window.location.href = "/exam/question/" + id
        });
    });
    
    function deleteQuestion(id)
        {
            var url = "<?php echo e(route('delete_question', 'id')); ?>";
            var token = document.getElementsByName("_token")[0].value;
            url = url.replace('id', id);
            $.ajax({
                url: url,
                method: 'DELETE',
                data: {
                        "id": id,
                        "_method": 'DELETE',
                        "_token": token,
                },
                dataType: 'JSON',
                success: function ()
                {
                    swal('Success', 'Successfully deleted', 'sucess')
                    window.location.reload()
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('../../../layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/admin/exam/update.blade.php ENDPATH**/ ?>