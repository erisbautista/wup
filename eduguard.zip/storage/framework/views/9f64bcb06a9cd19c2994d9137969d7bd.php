

<?php $__env->startSection('title','Strands'); ?>

<?php $__env->startSection('header'); ?>
    <h1>BROWSE STRANDS</h1>
    <h2>Review your willingness or eagerness to select a strand description.</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ncae-menu'); ?>
    <div class="side-nav" id="menu">
        <p class="fs-2 text-uppercase text-center">SELECT STRAND</p>
        <?php $__currentLoopData = $strands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $strand): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <button type="button" onclick="fillStrandInfo(<?php echo e($strand); ?>)" id="<?php echo e($strand->name); ?>" class="btn-menu text-center m-5"><?php echo e($strand->name); ?></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ncae-content'); ?>
    <div class="ncae-strand">
        <div class="strand-info">
            <div class="description">
                <h1 class="description-header">Description</h1>
                <p id="description"><?php echo e($strands[0]->description); ?></p>
            </div>
            <div class="expectation">
                <h1 class="expectation-header">Expectation</h1>
                <p id="expectation"><?php echo e($strands[0]->expectation); ?></p>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center text-uppercase" href="<?php echo e(route('ncae')); ?>">
    Main Menu
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        $('#stem').css('background-color', '#62B485');
    });

    function fillStrandInfo(strand) {
        $('#menu :button').css('background-color', '#247547');
        $('#' + strand.name).css('background-color', '#62B485');
        $('#description').html(strand.description);
        $('#expectation').html(strand.expectation);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../../layouts.ncae', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\ncae\strand.blade.php ENDPATH**/ ?>