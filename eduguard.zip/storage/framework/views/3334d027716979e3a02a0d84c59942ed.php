

<?php $__env->startSection('title','Violations'); ?>

<?php $__env->startSection('header'); ?>
    <h1>STUDENT VIOLATION TRACKER</h1>
    <h2>MAIN MENU</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('violation-content'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('home')); ?>">
    Main Menu
</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.violation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views/pages/violation.blade.php ENDPATH**/ ?>