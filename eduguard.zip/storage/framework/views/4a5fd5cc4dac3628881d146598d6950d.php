

<?php $__env->startSection('title','NCAE'); ?>

<?php $__env->startSection('header'); ?>
    <h1>NCAE PRE-TEST</h1>
    <h2>Navigate your dream strand and future courses.</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ncae-menu'); ?>
    <div class="side-nav">
        <p class="fs-1 text-uppercase text-center">Main Menu</p>
        <a id="ncae-test-menu" class="btn-menu text-center">TAKE PRE-TEST</a>
        <a href="<?php echo e(route('ncae_strand')); ?>" id="ncae-strand-menu" class="btn-menu text-center">BROWSE STRANDS</a>
        <a href="<?php echo e(route('ncae_career')); ?>" id="ncae-career-menu" class="btn-menu text-center">RELATED CAREERS</a>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('ncae-content'); ?>
    <div class="ncae-menu-content">
        <p class="quote">
            <span>"A career choice is an</span>
            <span>expression of personality"</span>
            <span>- Dr. John Holland</span>
        </p>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>
<a class="button w-5 text-center" href="<?php echo e(route('home')); ?>">
    Main Menu
</a>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
    document.addEventListener("DOMContentLoaded", function () {
        $('.side-nav').on('click', '#ncae-test-menu', function (e) {
            e.preventDefault();
            swal({
                text: 'Welcome to the NCAE Pre-Test! Before starting, please ensure you are in a quiet space with a stable internet connection and have all necessary materials on hand. Read each question carefully, manage your time wisely, and avoid distractions during the exam. Cheating or opening unauthorized websites is strictly prohibited and will lead to disqualification. Take a deep breath, stay calm, and do your best. Good luck on this important step towards discovering your future career path!',
                icon: "warning",
                buttons: true,
                dangerMode: true,
            }).then((confirm) => {
                if(confirm) {
                    window.location.href = "/ncae/test"
                }
            })
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('../layouts.ncae', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\wup\resources\views\pages\ncae.blade.php ENDPATH**/ ?>