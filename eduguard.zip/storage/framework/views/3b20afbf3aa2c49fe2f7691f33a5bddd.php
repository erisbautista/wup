<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title><?php echo $__env->yieldContent('title'); ?></title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />
        <script src="https://code.jquery.com/jquery-3.6.1.min.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
        <link  href="https://cdn.datatables.net/1.10.21/css/jquery.dataTables.min.css" rel="stylesheet">
        
        <script src="https://cdn.datatables.net/1.10.21/js/jquery.dataTables.min.js"></script>

        <?php echo app('Illuminate\Foundation\Vite')(['resources/sass/main.scss', 'resources/js/app.js']); ?>
    </head>
    <body>
        <div class="container">
            <div class="header mb-4">
                <?php echo $__env->yieldContent('header'); ?>
            </div>
            <div class="main">
                <div class="side-nav">
                    <a href="<?php echo e(route('user_violation_register_view')); ?>" id="register-violation-menu" class="btn-menu text-center">REGISTER VIOLATION</a>
                    <a href="<?php echo e(route('user_violation_record')); ?>" id="record-violation-menu" class="btn-menu text-center">STUDENT RECORDS</a>
                    <a href="<?php echo e(route('user_violation_analysis')); ?>" id="analysis-violation-menu" class="btn-menu text-center">VIOLATION ANALYSIS</a>
                    <a href="<?php echo e(route('user_violation_recent')); ?>" id="recent-violation-menu" class="btn-menu text-center">RECENT VIOLATIONS</a>
                </div>
                <div class="content">
                    <div class="card">
                        <?php echo $__env->yieldContent('violation-content'); ?>
                    </div>
                </div>
                <div class="footer">
                    <?php echo $__env->yieldContent('footer'); ?>
                </div>
            </div>
        </div>
        <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('script'); ?>
    </body>
</html>
<?php /**PATH C:\xampp\htdocs\wup\resources\views///////layouts/violation.blade.php ENDPATH**/ ?>