import "./bootstrap";
import "./admin";
import swal from "sweetalert";
window.Swal = swal;
import flatpickr from "flatpickr";
import moment from "moment";
