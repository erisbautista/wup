<div id="ncae-modal" class="modal">
    <div class="modal-body">
        Test
    </div>
</div>